class CurrentlyNotSupported(Exception):
	pass