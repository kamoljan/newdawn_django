Bugs
====
Maybe several, please report `issues in github`_

.. _issues in github: https://github.com/omab/django-social-auth/issues
