Contributions
=============

Attributions to whom deserves:

caioariede_ (Caio Ariede):
  * Improvements and Orkut support

krvss_ (Stas Kravets):
  * Initial setup.py configuration
  * LiveJournal support
  * Mail.ru, Odnoklassniki support
  * Yandex OpenID support
  * VKontakte OpenAPI support

jezdez_ (Jannis Leidel):
  * Improvements and documentation update

alfredo_ (Alfredo Ramirez)
  * Facebook and Doc improvements

mattucf_ (Matt Brown)
  * Twitter and OAuth improvements

Quard_ (Vadym Zakovinko)
  * LinkedIn support

micrypt_ (Seyi Ogunyemi)
  * python-oauth2_ migration

djm_ (Darian Moody)
  * Improvements

bernardokyotoku_ (Bernardo Kyotoku)
  * Improvements

maraujop_ (Miguel Araujo)
  * Improvements

bedspax_
  * Foursquare support

revolunet_ (Julien Bouquillon)
  * GitHub support

danielgtaylor_ (Daniel G. Taylor)
  * Dropbox support
  * Flickr support
  * Provider name context processor

r4vi_ (Ravi Kotecha)
  * Instagram support

andrusha_ (Andrew Korzhuev)
  * MSN Live Connect support
  * Yahoo OAuth 1.0 support

niQo_ (Nicolas Quiénot)
  * Skyrock.com support

hassek_ (Tomas Henriquez)
  * Evernote support

fmoga_ (Florian Moga)
  * Mixcloud support

estebistec_ (Steven Cummings)
  * Overrideable models feature

hepochen_
  * Weibo support

northisup_ (Adam Hitchcock)
  * DISQUS support

kjoconnor_ (Kevin O'Connor)
  * Readablity Support

uruz_ (Alexey Boriskin)
  * Odnoklassniki.ru iframe applications support
  * VK.com backend improvements

abompard_ (Aurélien Bompard)
  * Fedora OpenID support

dhendo_ (David Henderson)
  * Shopify support
  * ExactTarget support

gardaud_ (Guillaume Ardaud)
  * Option to revoke providers' tokens on disconnect.

.. _caioariede: https://github.com/caioariede
.. _krvss: https://github.com/krvss
.. _jezdez: https://github.com/jezdez
.. _alfredo: https://github.com/alfredo
.. _mattucf: https://github.com/mattucf
.. _Quard: https://github.com/Quard
.. _micrypt: https://github.com/micrypt
.. _djm: https://github.com/djm
.. _bernardokyotoku: https://github.com/bernardokyotoku
.. _andrusha: https://github.com/andrusha
.. _maraujop: https://github.com/maraujop
.. _bedspax: https://github.com/bedspax
.. _python-oauth2: https://github.com/simplegeo/python-oauth2
.. _niQo: https://github.com/niQo
.. _hassek: https://github.com/hassek
.. _fmoga: https://github.com/fmoga
.. _revolunet: https://github.com/revolunet
.. _r4vi: https://github.com/r4vi
.. _danielgtaylor: https://github.com/danielgtaylor
.. _estebistec: https://github.com/estebistec
.. _hepochen: https://github.com/hepochen
.. _northisup: https://github.com/northisup
.. _kjoconnor: https://github.com/kjoconnor
.. _uruz: https://github.com/uruz
.. _abompard: https://github.com/abompard
.. _dhendo: https://github.com/dhendo
.. _gardaud: https://github.com/gardaud