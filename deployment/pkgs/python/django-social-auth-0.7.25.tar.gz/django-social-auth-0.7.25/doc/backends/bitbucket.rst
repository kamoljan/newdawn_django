Bitbucket
^^^^^^^^^
Bitbucket works similar to Twitter (OAuth).

- Register a new application by emailing ``support@bitbucket.org`` with an
  application name and a bit of a description,

- Fill ``Consumer Key`` and ``Consumer Secret`` values in the settings::

      BITBUCKET_CONSUMER_KEY = ''
      BITBUCKET_CONSUMER_SECRET = ''
