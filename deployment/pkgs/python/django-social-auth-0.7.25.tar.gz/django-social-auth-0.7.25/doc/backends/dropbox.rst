Dropbox
^^^^^^^

Dropbox uses OAuth v1.0 for authentication.

- Register a new application at `Dropbox Developers`_, and

- fill ``App Key`` and ``App Secret`` values in the settings::

      DROPBOX_APP_ID = ''
      DROPBOX_API_SECRET = ''

.. _Dropbox Developers: https://www.dropbox.com/developers/apps
