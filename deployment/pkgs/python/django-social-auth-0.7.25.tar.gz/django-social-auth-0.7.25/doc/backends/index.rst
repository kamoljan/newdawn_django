Django Social Auth backends system
==================================

Contents:

.. toctree::
   :maxdepth: 2

   oauth
   openid

   amazon
   angel
   appsfuel
   behance
   bitbucket
   browserid
   disqus
   douban
   dropbox
   evernote
   exacttarget
   facebook
   flickr
   github
   google
   instagram
   linkedin
   live
   mailru
   mixcloud
   odnoklassnikiru
   rdio
   readability
   reddit
   shopify
   skyrock
   soundcloud
   stackoverflow
   steam
   stocktwits
   stripe
   tripit
   tumblr
   twilio
   twitter
   vk
   weibo
   yahoo
