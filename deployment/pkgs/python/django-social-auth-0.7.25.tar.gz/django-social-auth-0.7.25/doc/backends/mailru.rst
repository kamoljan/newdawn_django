Mail.ru OAuth
=============

Mail.ru uses OAuth2 workflow, to use it fill in settings::

    MAILRU_OAUTH2_CLIENT_KEY = ''
    MAILRU_OAUTH2_APP_KEY = ''
    MAILRU_OAUTH2_CLIENT_SECRET = ''
