Mendeley
=========
Mendeley uses OAuth v2 for Authentication

- Register a new application at the `Mendeley API`_, and

- fill ``Consumer Key`` and ``Consumer Secret`` values in the settings::

      MENDELEY_CONSUMER_KEY = ''
      MENDELEY_CONSUMER_SECRET = ''

.. _Mendeley API: http://apidocs.mendeley.com/
