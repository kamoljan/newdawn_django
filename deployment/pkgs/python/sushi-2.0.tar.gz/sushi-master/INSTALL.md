*sushid* depends on the high performance web framework *tornado*, download it from http://tornadoweb.org, and run:

    python setup.py build

to install sushi, just run:

    sudo python setup.py install

to fire a sushi, just run:

    sushid start