#!/bin/sh -v

python setup.py sdist
