#!/usr/bin/env python

from distutils.core import setup

setup(name='sushi',
      version='1.0',
      description='a simple file storage service',
      author='Steve Chu',
      author_email='steve@tokyoscale.com',
      url='http://www.tokyoscale.com',
      py_modules=['sushi', ],
      data_files=[('/usr/local/bin', ['sushid.py', 'sushid']),
                  ('/etc', ['sushid.conf'])]
)
