#define SPH_SVN_TAG "beta"
#define SPH_SVN_REV 3701
#define SPH_SVN_REVSTR "3701"
#define SPH_SVN_TAGREV "rel21-r3701"
#define SPHINX_TAG "-beta"
