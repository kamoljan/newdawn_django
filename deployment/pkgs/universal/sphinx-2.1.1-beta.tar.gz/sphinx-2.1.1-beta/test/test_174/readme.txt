On some OS (e.g. openSuse 10.3 ) on some PHP versions (e.g. 5.2.11) fread works incorrect if third argument ($length) is more than 8192. 
